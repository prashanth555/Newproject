import UIKit

final class GameOverViewController: UIViewController {

    private let gradientLayer = CAGradientLayer()

    override func viewDidLoad() {
        super.viewDidLoad()
        buildUI()
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        gradientLayer.frame = view.bounds
    }

    override var supportedInterfaceOrientations: UIInterfaceOrientationMask { .landscape }
    override var prefersStatusBarHidden: Bool { true }

    private func buildUI() {
        // Gradient bg
        gradientLayer.colors = [
            UIColor(red: 0.04, green: 0.09, blue: 0.22, alpha: 1).cgColor,
            UIColor(red: 0.15, green: 0.04, blue: 0.04, alpha: 1).cgColor
        ]
        gradientLayer.startPoint = CGPoint(x: 0, y: 0)
        gradientLayer.endPoint   = CGPoint(x: 1, y: 1)
        view.layer.insertSublayer(gradientLayer, at: 0)

        let gm    = GameManager.shared
        let score = gm.innings.runs
        let wkts  = gm.innings.wickets
        let overs = gm.innings.overDisplay
        let best  = gm.highScore
        let isNew = score == best && best > 0

        // Container card
        let card = UIView()
        card.backgroundColor   = UIColor(white: 1, alpha: 0.07)
        card.layer.cornerRadius = 20
        card.layer.borderWidth  = 1
        card.layer.borderColor  = UIColor(white: 1, alpha: 0.15).cgColor
        card.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(card)

        // Game Over title
        let goLabel = UILabel()
        goLabel.text      = "INNINGS OVER"
        goLabel.font      = UIFont.systemFont(ofSize: 28, weight: .heavy)
        goLabel.textColor = UIColor(red: 1, green: 0.6, blue: 0.3, alpha: 1)
        goLabel.textAlignment = .center
        goLabel.translatesAutoresizingMaskIntoConstraints = false
        card.addSubview(goLabel)

        // Score display
        let scoreLabel = UILabel()
        scoreLabel.text      = "\(score)/\(wkts)"
        scoreLabel.font      = UIFont.systemFont(ofSize: 72, weight: .heavy)
        scoreLabel.textColor = .white
        scoreLabel.textAlignment = .center
        scoreLabel.layer.shadowColor   = UIColor.white.cgColor
        scoreLabel.layer.shadowRadius  = 10
        scoreLabel.layer.shadowOpacity = 0.4
        scoreLabel.layer.shadowOffset  = .zero
        scoreLabel.translatesAutoresizingMaskIntoConstraints = false
        card.addSubview(scoreLabel)

        // Overs info
        let overLabel = UILabel()
        overLabel.text      = "Overs: \(overs)  |  Wickets: \(wkts)"
        overLabel.font      = UIFont.systemFont(ofSize: 17, weight: .medium)
        overLabel.textColor = UIColor(white: 0.7, alpha: 1)
        overLabel.textAlignment = .center
        overLabel.translatesAutoresizingMaskIntoConstraints = false
        card.addSubview(overLabel)

        // High score
        let hsLabel = UILabel()
        hsLabel.text      = isNew ? "🏆 NEW HIGH SCORE!" : "Best: \(best)"
        hsLabel.font      = UIFont.systemFont(ofSize: isNew ? 20 : 16, weight: isNew ? .bold : .regular)
        hsLabel.textColor = isNew
            ? UIColor(red: 1, green: 0.84, blue: 0.1, alpha: 1)
            : UIColor(white: 0.5, alpha: 1)
        hsLabel.textAlignment = .center
        hsLabel.translatesAutoresizingMaskIntoConstraints = false
        card.addSubview(hsLabel)

        // Grade banner
        let grade  = scoreGrade(score)
        let gradeL = UILabel()
        gradeL.text      = grade
        gradeL.font      = UIFont.systemFont(ofSize: 18, weight: .semibold)
        gradeL.textColor = UIColor(red: 0.4, green: 0.9, blue: 0.5, alpha: 1)
        gradeL.textAlignment = .center
        gradeL.translatesAutoresizingMaskIntoConstraints = false
        card.addSubview(gradeL)

        // Play again
        let playBtn = makeButton(title: "▶  PLAY AGAIN", bg: UIColor(red: 0.1, green: 0.7, blue: 0.3, alpha: 1))
        playBtn.addTarget(self, action: #selector(playAgain), for: .touchUpInside)
        card.addSubview(playBtn)

        // Main menu
        let menuBtn = makeButton(title: "⌂  MAIN MENU", bg: UIColor(white: 0.2, alpha: 0.8))
        menuBtn.addTarget(self, action: #selector(goMenu), for: .touchUpInside)
        card.addSubview(menuBtn)

        // Layout
        NSLayoutConstraint.activate([
            card.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            card.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            card.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 0.6),
            card.heightAnchor.constraint(equalTo: view.heightAnchor, multiplier: 0.88),

            goLabel.topAnchor.constraint(equalTo: card.topAnchor, constant: 24),
            goLabel.centerXAnchor.constraint(equalTo: card.centerXAnchor),

            scoreLabel.topAnchor.constraint(equalTo: goLabel.bottomAnchor, constant: 12),
            scoreLabel.centerXAnchor.constraint(equalTo: card.centerXAnchor),

            overLabel.topAnchor.constraint(equalTo: scoreLabel.bottomAnchor, constant: 4),
            overLabel.centerXAnchor.constraint(equalTo: card.centerXAnchor),

            hsLabel.topAnchor.constraint(equalTo: overLabel.bottomAnchor, constant: 10),
            hsLabel.centerXAnchor.constraint(equalTo: card.centerXAnchor),

            gradeL.topAnchor.constraint(equalTo: hsLabel.bottomAnchor, constant: 10),
            gradeL.centerXAnchor.constraint(equalTo: card.centerXAnchor),

            playBtn.centerXAnchor.constraint(equalTo: card.centerXAnchor),
            playBtn.bottomAnchor.constraint(equalTo: menuBtn.topAnchor, constant: -14),
            playBtn.widthAnchor.constraint(equalToConstant: 200),
            playBtn.heightAnchor.constraint(equalToConstant: 52),

            menuBtn.centerXAnchor.constraint(equalTo: card.centerXAnchor),
            menuBtn.bottomAnchor.constraint(equalTo: card.bottomAnchor, constant: -28),
            menuBtn.widthAnchor.constraint(equalToConstant: 200),
            menuBtn.heightAnchor.constraint(equalToConstant: 52)
        ])

        if isNew { addConfetti() }
    }

    private func makeButton(title: String, bg: UIColor) -> UIButton {
        let btn = UIButton(type: .system)
        btn.setTitle(title, for: .normal)
        btn.titleLabel?.font = UIFont.systemFont(ofSize: 18, weight: .bold)
        btn.setTitleColor(.white, for: .normal)
        btn.backgroundColor   = bg
        btn.layer.cornerRadius = 26
        btn.layer.borderWidth  = 1
        btn.layer.borderColor  = UIColor(white: 1, alpha: 0.25).cgColor
        btn.translatesAutoresizingMaskIntoConstraints = false
        return btn
    }

    private func scoreGrade(_ score: Int) -> String {
        switch score {
        case 200...: return "WORLD CLASS! 🌟"
        case 160...: return "OUTSTANDING! 🔥"
        case 120...: return "EXCELLENT BAT! 👏"
        case  80...: return "SOLID INNINGS!"
        case  40...: return "Could do better..."
        default:     return "Keep practising!"
        }
    }

    private func addConfetti() {
        let emitter       = CAEmitterLayer()
        emitter.emitterPosition = CGPoint(x: view.bounds.midX, y: -10)
        emitter.emitterShape    = .line
        emitter.emitterSize     = CGSize(width: view.bounds.width, height: 1)

        let colors: [UIColor] = [.red, .green, .blue, .yellow, .magenta, .cyan, .orange]
        emitter.emitterCells = colors.map { color in
            let cell               = CAEmitterCell()
            cell.birthRate         = 6
            cell.lifetime          = 5
            cell.velocity          = 200
            cell.velocityRange     = 60
            cell.emissionLongitude = .pi
            cell.emissionRange     = .pi / 4
            cell.spin              = 2
            cell.spinRange         = 3
            cell.scale             = 0.07
            cell.scaleRange        = 0.03
            cell.color             = color.cgColor
            cell.contents          = makeConfettiShape().cgImage
            return cell
        }
        view.layer.addSublayer(emitter)

        DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
            emitter.birthRate = 0
        }
    }

    private func makeConfettiShape() -> UIImage {
        let size = CGSize(width: 10, height: 6)
        let renderer = UIGraphicsImageRenderer(size: size)
        return renderer.image { ctx in
            ctx.cgContext.setFillColor(UIColor.white.cgColor)
            ctx.cgContext.fill(CGRect(origin: .zero, size: size))
        }
    }

    // MARK: - Actions

    @objc private func playAgain() {
        UIImpactFeedbackGenerator(style: .medium).impactOccurred()
        dismiss(animated: false) {
            let gameVC = GameViewController()
            gameVC.modalPresentationStyle = .fullScreen
            // Find root nav and present
            if let root = UIApplication.shared.connectedScenes
                .compactMap({ $0 as? UIWindowScene })
                .first?.windows.first?.rootViewController {
                root.present(gameVC, animated: true)
            }
        }
    }

    @objc private func goMenu() {
        UIImpactFeedbackGenerator(style: .light).impactOccurred()
        dismiss(animated: true) {
            // Pop to root (main menu)
            if let nav = UIApplication.shared.connectedScenes
                .compactMap({ $0 as? UIWindowScene })
                .first?.windows.first?.rootViewController as? UINavigationController {
                nav.popToRootViewController(animated: false)
                // Dismiss any presented VCs on top of nav
                nav.presentedViewController?.dismiss(animated: false)
            }
        }
    }
}
