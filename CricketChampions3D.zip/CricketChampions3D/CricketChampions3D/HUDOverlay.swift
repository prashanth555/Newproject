import SpriteKit
import UIKit

// MARK: - HUDOverlay (SpriteKit scene rendered over the SCNView)

final class HUDOverlay: SKScene {

    // Top bar nodes
    private var scoreLabel:  SKLabelNode!
    private var oversLabel:  SKLabelNode!
    private var wicketLabel: SKLabelNode!

    // Delivery type banner
    private var deliveryBanner: SKNode!
    private var deliveryLabel:  SKLabelNode!

    // Big run animation
    private var runNode: SKNode!
    private var runLabel: SKLabelNode!

    // Batting hint
    private var hintNode: SKNode!
    private var hintLabel: SKLabelNode!

    // Wicket panel
    private var wicketPanel: SKNode!
    private var wicketMsgLabel: SKLabelNode!

    // Sizes
    private var screenW: CGFloat { size.width }
    private var screenH: CGFloat { size.height }

    // MARK: - Init

    override init(size: CGSize) {
        super.init(size: size)
        isUserInteractionEnabled = false
        buildHUD()
        subscribeNotifications()
    }
    required init?(coder: NSCoder) { super.init(coder: coder) }

    deinit {
        NotificationCenter.default.removeObserver(self)
    }

    // MARK: - Build

    private func buildHUD() {
        buildTopBar()
        buildDeliveryBanner()
        buildRunAnimation()
        buildHint()
        buildWicketPanel()
    }

    private func buildTopBar() {
        let barH: CGFloat = 72
        let bar = SKShapeNode(rect: CGRect(x: 0, y: screenH - barH, width: screenW, height: barH),
                               cornerRadius: 0)
        bar.fillColor   = UIColor(white: 0, alpha: 0.55)
        bar.strokeColor = .clear
        addChild(bar)

        // Score
        scoreLabel = makeLabelNode(text: "0/0", size: 28, weight: .bold, color: .white)
        scoreLabel.position = CGPoint(x: screenW * 0.22, y: screenH - 42)
        scoreLabel.horizontalAlignmentMode = .center
        addChild(scoreLabel)

        // Over
        oversLabel = makeLabelNode(text: "Ov: 0.0", size: 20, weight: .semibold, color: UIColor(white: 0.85, alpha: 1))
        oversLabel.position = CGPoint(x: screenW * 0.5, y: screenH - 40)
        oversLabel.horizontalAlignmentMode = .center
        addChild(oversLabel)

        // Wickets ticker
        wicketLabel = makeLabelNode(text: "Wkts: 0", size: 20, weight: .semibold, color: UIColor(red: 1, green: 0.6, blue: 0.3, alpha: 1))
        wicketLabel.position = CGPoint(x: screenW * 0.78, y: screenH - 40)
        wicketLabel.horizontalAlignmentMode = .center
        addChild(wicketLabel)

        // Label subtitles
        let scoreTitle = makeLabelNode(text: "SCORE", size: 11, weight: .regular, color: UIColor(white: 0.65, alpha: 1))
        scoreTitle.position = CGPoint(x: screenW * 0.22, y: screenH - 58)
        scoreTitle.horizontalAlignmentMode = .center
        addChild(scoreTitle)
    }

    private func buildDeliveryBanner() {
        deliveryBanner = SKNode()
        deliveryBanner.position = CGPoint(x: screenW / 2, y: screenH - 115)
        deliveryBanner.alpha = 0

        let bg = SKShapeNode(rect: CGRect(x: -90, y: -18, width: 180, height: 36), cornerRadius: 8)
        bg.fillColor   = UIColor(red: 0.9, green: 0.3, blue: 0.1, alpha: 0.9)
        bg.strokeColor = .clear
        deliveryBanner.addChild(bg)

        deliveryLabel = makeLabelNode(text: "FAST BALL", size: 18, weight: .bold, color: .white)
        deliveryLabel.position = CGPoint(x: 0, y: -6)
        deliveryLabel.horizontalAlignmentMode = .center
        deliveryBanner.addChild(deliveryLabel)

        addChild(deliveryBanner)
    }

    private func buildRunAnimation() {
        runNode = SKNode()
        runNode.position = CGPoint(x: screenW / 2, y: screenH / 2 + 30)
        runNode.alpha    = 0
        runNode.setScale(0.5)

        runLabel = makeLabelNode(text: "6!", size: 90, weight: .heavy, color: .yellow)
        runLabel.position = .zero
        runLabel.horizontalAlignmentMode = .center
        runNode.addChild(runLabel)
        addChild(runNode)
    }

    private func buildHint() {
        hintNode  = SKNode()
        hintNode.position = CGPoint(x: screenW / 2, y: 55)
        hintNode.alpha    = 0

        let bg = SKShapeNode(rect: CGRect(x: -120, y: -18, width: 240, height: 36), cornerRadius: 10)
        bg.fillColor   = UIColor(white: 0, alpha: 0.5)
        bg.strokeColor = UIColor(white: 1, alpha: 0.3)
        bg.lineWidth   = 1
        hintNode.addChild(bg)

        hintLabel = makeLabelNode(text: "SWIPE TO HIT!", size: 17, weight: .bold, color: .white)
        hintLabel.position = CGPoint(x: 0, y: -6)
        hintLabel.horizontalAlignmentMode = .center
        hintNode.addChild(hintLabel)

        addChild(hintNode)
    }

    private func buildWicketPanel() {
        wicketPanel = SKNode()
        wicketPanel.position = CGPoint(x: screenW / 2, y: screenH / 2)
        wicketPanel.alpha    = 0
        wicketPanel.setScale(0.6)

        let bg = SKShapeNode(rect: CGRect(x: -150, y: -50, width: 300, height: 100), cornerRadius: 16)
        bg.fillColor   = UIColor(red: 0.75, green: 0.05, blue: 0.05, alpha: 0.92)
        bg.strokeColor = UIColor(red: 1, green: 0.5, blue: 0.5, alpha: 0.5)
        bg.lineWidth   = 2
        wicketPanel.addChild(bg)

        wicketMsgLabel = makeLabelNode(text: "BOWLED!", size: 32, weight: .heavy, color: .white)
        wicketMsgLabel.position = CGPoint(x: 0, y: 5)
        wicketMsgLabel.horizontalAlignmentMode = .center
        wicketPanel.addChild(wicketMsgLabel)

        addChild(wicketPanel)
    }

    // MARK: - Notifications

    private func subscribeNotifications() {
        let nc = NotificationCenter.default
        nc.addObserver(self, selector: #selector(onRunsScored(_:)),   name: .runsScored,   object: nil)
        nc.addObserver(self, selector: #selector(onWicket(_:)),       name: .wicketFell,   object: nil)
        nc.addObserver(self, selector: #selector(onDotBall),          name: .dotBall,      object: nil)
        nc.addObserver(self, selector: #selector(onNextBall),         name: .nextBall,     object: nil)
        nc.addObserver(self, selector: #selector(onDelivery(_:)),     name: .deliveryType, object: nil)
        nc.addObserver(self, selector: #selector(onShowRunAnim(_:)),  name: .showRunAnim,  object: nil)
    }

    @objc private func onRunsScored(_ n: Notification) {
        DispatchQueue.main.async { self.refreshScoreBoard() }
    }

    @objc private func onWicket(_ n: Notification) {
        guard let type = n.object as? DismissalType else { return }
        DispatchQueue.main.async {
            self.showWicketPanel(message: type.rawValue)
            self.refreshScoreBoard()
        }
    }

    @objc private func onDotBall() {
        DispatchQueue.main.async { self.refreshScoreBoard() }
    }

    @objc private func onNextBall() {
        DispatchQueue.main.async { self.showHint(false); self.refreshScoreBoard() }
    }

    @objc private func onDelivery(_ n: Notification) {
        guard let d = n.object as? DeliveryType else { return }
        DispatchQueue.main.async { self.showDeliveryBanner(d.rawValue) }
        // Show hint a bit after
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.7) {
            self.showHint(true)
        }
    }

    @objc private func onShowRunAnim(_ n: Notification) {
        guard let runs = n.object as? Int else { return }
        DispatchQueue.main.async { self.animateRunBurst(runs) }
    }

    // MARK: - Update helpers

    private func refreshScoreBoard() {
        let gm = GameManager.shared
        scoreLabel.text  = gm.scoreDisplay
        oversLabel.text  = "Ov: \(gm.overDisplay)"
        wicketLabel.text = "Wkts: \(gm.innings.wickets)"
    }

    private func showDeliveryBanner(_ text: String) {
        deliveryLabel.text = text
        deliveryBanner.removeAllActions()
        let show = SKAction.sequence([
            SKAction.group([SKAction.fadeIn(withDuration: 0.2),
                            SKAction.scale(to: 1.0, duration: 0.2)]),
            SKAction.wait(forDuration: 1.6),
            SKAction.fadeOut(withDuration: 0.3)
        ])
        deliveryBanner.run(show)
    }

    private func showHint(_ visible: Bool) {
        hintNode.removeAllActions()
        if visible {
            let pulse = SKAction.sequence([
                SKAction.fadeIn(withDuration: 0.3),
                SKAction.scale(to: 1.05, duration: 0.5),
                SKAction.scale(to: 1.0, duration: 0.5)
            ])
            hintNode.run(SKAction.repeatForever(pulse))
        } else {
            hintNode.run(SKAction.fadeOut(withDuration: 0.2))
        }
    }

    private func animateRunBurst(_ runs: Int) {
        let isSix  = runs == 6
        runLabel.text      = isSix ? "SIX!" : "FOUR!"
        runLabel.fontColor = isSix ? .yellow : SKColor(red: 0.3, green: 0.9, blue: 0.4, alpha: 1)
        runNode.removeAllActions()
        runNode.alpha = 1
        runNode.setScale(0.4)
        let anim = SKAction.sequence([
            SKAction.group([SKAction.fadeIn(withDuration: 0.2),
                            SKAction.scale(to: 1.1, duration: 0.3)]),
            SKAction.scale(to: 1.0, duration: 0.1),
            SKAction.wait(forDuration: 1.0),
            SKAction.group([SKAction.fadeOut(withDuration: 0.4),
                            SKAction.scale(to: 1.4, duration: 0.4)])
        ])
        runNode.run(anim)
    }

    private func showWicketPanel(message: String) {
        wicketMsgLabel.text = message
        wicketPanel.removeAllActions()
        wicketPanel.alpha = 0
        wicketPanel.setScale(0.6)
        let anim = SKAction.sequence([
            SKAction.group([SKAction.fadeIn(withDuration: 0.25),
                            SKAction.scale(to: 1.0, duration: 0.25)]),
            SKAction.wait(forDuration: 1.8),
            SKAction.group([SKAction.fadeOut(withDuration: 0.3),
                            SKAction.scale(to: 1.3, duration: 0.3)])
        ])
        wicketPanel.run(anim)
    }

    // MARK: - Utility

    private func makeLabelNode(text: String, size: CGFloat,
                                weight: UIFont.Weight, color: UIColor) -> SKLabelNode {
        let label = SKLabelNode(text: text)
        label.fontName  = UIFont.systemFont(ofSize: size, weight: weight).fontName
        label.fontSize  = size
        label.fontColor = SKColor(cgColor: color.cgColor)
        label.verticalAlignmentMode = .center
        return label
    }
}
