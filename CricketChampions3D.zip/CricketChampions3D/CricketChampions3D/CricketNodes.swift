import SceneKit
import UIKit

// MARK: - BallNode

final class BallNode: SCNNode {

    override init() {
        super.init()
        setup()
    }
    required init?(coder: NSCoder) { super.init(coder: coder); setup() }

    private func setup() {
        let sphere = SCNSphere(radius: 0.072)
        let mat    = SCNMaterial()
        mat.diffuse.contents   = UIColor(red: 0.78, green: 0.08, blue: 0.08, alpha: 1)
        mat.roughness.contents = 0.55
        mat.metalness.contents = 0.15
        sphere.materials = [mat]
        geometry = sphere
        name     = "ball"

        // Seam ring
        let seamTorus = SCNTorus(ringRadius: 0.072, pipeRadius: 0.006)
        seamTorus.firstMaterial?.diffuse.contents = UIColor(red: 0.9, green: 0.75, blue: 0.65, alpha: 1)
        seamTorus.firstMaterial?.roughness.contents = 0.9
        let seamNode = SCNNode(geometry: seamTorus)
        seamNode.eulerAngles.x = Float.pi / 2
        addChildNode(seamNode)

        // Physics
        let shape  = SCNPhysicsShape(geometry: sphere, options: nil)
        physicsBody = SCNPhysicsBody(type: .dynamic, shape: shape)
        physicsBody?.mass               = 0.156
        physicsBody?.friction           = 0.5
        physicsBody?.restitution        = 0.62
        physicsBody?.damping            = 0.08
        physicsBody?.angularDamping     = 0.15
        physicsBody?.categoryBitMask    = PhysicsCategory.ball
        physicsBody?.collisionBitMask   = PhysicsCategory.ground | PhysicsCategory.stumps
        physicsBody?.contactTestBitMask = PhysicsCategory.stumps | PhysicsCategory.boundary
    }

    func addTrail() {
        let trail               = SCNParticleSystem()
        trail.birthRate         = 150
        trail.particleLifeSpan  = 0.25
        trail.particleSize      = 0.04
        trail.particleColor     = UIColor(red: 1, green: 0.4, blue: 0.4, alpha: 0.6)
        trail.emittingDirection = SCNVector3(0, 1, 0)
        trail.spreadingAngle    = 180
        trail.particleVelocity  = 0.1
        addParticleSystem(trail)
    }
}

// MARK: - BatsmanNode

final class BatsmanNode: SCNNode {

    var batNode: SCNNode!

    override init() {
        super.init()
        setup()
    }
    required init?(coder: NSCoder) { super.init(coder: coder); setup() }

    private func setup() {
        name = "batsman"

        let blue   = UIColor(red: 0.05, green: 0.15, blue: 0.75, alpha: 1)
        let skin   = UIColor(red: 0.88, green: 0.72, blue: 0.58, alpha: 1)
        let white  = UIColor.white

        // --- Legs ---
        addLimb(pos: SCNVector3(-0.13, 0.33, 0), color: white, r: 0.1, h: 0.65)
        addLimb(pos: SCNVector3( 0.13, 0.33, 0), color: white, r: 0.1, h: 0.65)

        // Shoes
        addBox(pos: SCNVector3(-0.13, 0.05, 0.03), size: (0.21, 0.1, 0.32),
               color: UIColor(white: 0.9, alpha: 1))
        addBox(pos: SCNVector3( 0.13, 0.05, 0.03), size: (0.21, 0.1, 0.32),
               color: UIColor(white: 0.9, alpha: 1))

        // Pads (front)
        addBox(pos: SCNVector3(-0.13, 0.5, 0.11), size: (0.18, 0.75, 0.08), color: white)
        addBox(pos: SCNVector3( 0.13, 0.5, 0.11), size: (0.18, 0.75, 0.08), color: white)

        // --- Torso ---
        let torso = SCNCapsule(capRadius: 0.26, height: 0.78)
        torso.firstMaterial?.diffuse.contents = blue
        let torsoNode = SCNNode(geometry: torso)
        torsoNode.position = SCNVector3(0, 0.95, 0)
        addChildNode(torsoNode)

        // Arms
        addLimb(pos: SCNVector3(-0.38, 1.0, 0), color: blue, r: 0.09, h: 0.5,
                rotZ: Float.pi * 0.15)
        addLimb(pos: SCNVector3( 0.38, 1.0, 0), color: blue, r: 0.09, h: 0.5,
                rotZ: -Float.pi * 0.15)

        // Gloves
        addSphere(pos: SCNVector3(-0.38, 0.72, 0), r: 0.13, color: white)
        addSphere(pos: SCNVector3( 0.38, 0.72, 0), r: 0.13, color: white)

        // --- Head ---
        addSphere(pos: SCNVector3(0, 1.58, 0), r: 0.22, color: skin)

        // Helmet shell
        let helmet = SCNSphere(radius: 0.26)
        helmet.firstMaterial?.diffuse.contents = UIColor(red: 0.03, green: 0.08, blue: 0.5, alpha: 1)
        let helmetNode = SCNNode(geometry: helmet)
        helmetNode.position = SCNVector3(0, 1.60, 0)
        helmetNode.scale    = SCNVector3(1, 0.78, 1)
        addChildNode(helmetNode)

        // Visor
        addBox(pos: SCNVector3(0, 1.46, 0.22), size: (0.46, 0.08, 0.14),
               color: UIColor(white: 0.1, alpha: 0.75))

        // --- Bat ---
        batNode = makeBat()
        batNode.position    = SCNVector3(0.42, 0.52, 0.0)
        batNode.eulerAngles = SCNVector3(0, 0, Float.pi * 0.08)
        addChildNode(batNode)
    }

    private func makeBat() -> SCNNode {
        let bat = SCNNode()
        bat.name = "bat"

        // Handle
        let handle = SCNCylinder(radius: 0.025, height: 0.36)
        handle.firstMaterial?.diffuse.contents = UIColor(red: 0.55, green: 0.35, blue: 0.15, alpha: 1)
        let handleNode = SCNNode(geometry: handle)
        handleNode.position = SCNVector3(0, 0.62, 0)
        bat.addChildNode(handleNode)

        // Blade
        let blade = SCNBox(width: 0.11, height: 0.68, length: 0.044, chamferRadius: 0.012)
        blade.firstMaterial?.diffuse.contents   = UIColor(red: 0.84, green: 0.63, blue: 0.33, alpha: 1)
        blade.firstMaterial?.roughness.contents = 0.7
        let bladeNode = SCNNode(geometry: blade)
        bladeNode.position = SCNVector3(0, 0, 0)

        // Bat physics (kinematic – we drive it via animation)
        bladeNode.physicsBody = SCNPhysicsBody(type: .kinematic,
                                               shape: SCNPhysicsShape(geometry: blade, options: nil))
        bladeNode.physicsBody?.categoryBitMask    = PhysicsCategory.bat
        bladeNode.physicsBody?.collisionBitMask   = 0
        bladeNode.physicsBody?.contactTestBitMask = PhysicsCategory.ball
        bat.addChildNode(bladeNode)

        return bat
    }

    // MARK: Swing animation

    func swing(direction: CGPoint, completion: @escaping () -> Void) {
        let dx = Float(direction.x)
        let dy = Float(direction.y)

        // Choose shot type from swipe direction
        let rotZ: Float
        let rotX: Float
        let rotY: Float

        if dy > 0.5 {               // drive (forward)
            rotZ = -Float.pi * 0.5; rotX = 0;              rotY = dx * 0.3
        } else if dy < -0.5 {       // pull/hook
            rotZ = -Float.pi * 0.9; rotX = -Float.pi*0.4;  rotY = -dx * 0.4
        } else if dx > 0.4 {        // cut (off side)
            rotZ = -Float.pi * 0.6; rotX = Float.pi*0.1;   rotY = 0.3
        } else if dx < -0.4 {       // flick (leg side)
            rotZ = -Float.pi * 0.6; rotX = Float.pi*0.1;   rotY = -0.3
        } else {                    // straight
            rotZ = -Float.pi * 0.75; rotX = 0;             rotY = 0
        }

        let swing = SCNAction.sequence([
            SCNAction.rotateBy(x: CGFloat(rotX), y: CGFloat(rotY), z: CGFloat(rotZ), duration: 0.14),
            SCNAction.rotateBy(x: CGFloat(-rotX), y: CGFloat(-rotY), z: CGFloat(-rotZ*0.5), duration: 0.22)
        ])
        batNode.runAction(swing)

        let bodyTurn = SCNAction.sequence([
            SCNAction.rotateBy(x: 0, y: CGFloat(dx > 0 ? 0.4 : -0.4), z: 0, duration: 0.14),
            SCNAction.rotateBy(x: 0, y: CGFloat(dx > 0 ? -0.4 : 0.4), z: 0, duration: 0.22)
        ])
        runAction(bodyTurn) {
            completion()
        }
    }
}

// MARK: - BowlerNode

final class BowlerNode: SCNNode {

    override init() {
        super.init()
        setup()
    }
    required init?(coder: NSCoder) { super.init(coder: coder); setup() }

    private func setup() {
        name = "bowler"
        let red  = UIColor(red: 0.75, green: 0.08, blue: 0.08, alpha: 1)
        let skin = UIColor(red: 0.88, green: 0.72, blue: 0.58, alpha: 1)

        addLimb(pos: SCNVector3(-0.12, 0.33, 0), color: UIColor.white, r: 0.1, h: 0.65)
        addLimb(pos: SCNVector3( 0.12, 0.33, 0), color: UIColor.white, r: 0.1, h: 0.65)
        addBox(pos: SCNVector3(-0.12, 0.05, 0.03), size: (0.2, 0.1, 0.3), color: UIColor(white:0.85,alpha:1))
        addBox(pos: SCNVector3( 0.12, 0.05, 0.03), size: (0.2, 0.1, 0.3), color: UIColor(white:0.85,alpha:1))

        let torso = SCNCapsule(capRadius: 0.24, height: 0.76)
        torso.firstMaterial?.diffuse.contents = red
        let torsoNode = SCNNode(geometry: torso)
        torsoNode.position = SCNVector3(0, 0.93, 0)
        addChildNode(torsoNode)

        addLimb(pos: SCNVector3(-0.35, 1.0, 0), color: red,  r: 0.085, h: 0.5, rotZ:  Float.pi * 0.15)
        addLimb(pos: SCNVector3( 0.35, 1.0, 0), color: red,  r: 0.085, h: 0.5, rotZ: -Float.pi * 0.15)
        addSphere(pos: SCNVector3(0, 1.56, 0), r: 0.21, color: skin)

        // Cap
        let cap = SCNCylinder(radius: 0.26, height: 0.1)
        cap.firstMaterial?.diffuse.contents = red
        let capNode = SCNNode(geometry: cap)
        capNode.position = SCNVector3(0, 1.72, 0)
        addChildNode(capNode)
    }

    func animateRunUp(completion: @escaping () -> Void) {
        let forward  = SCNAction.moveBy(x: 0, y: 0, z: 3.5, duration: 1.1)
        let bounce1  = SCNAction.moveBy(x: 0, y: 0.15, z: 0, duration: 0.1)
        let bounce2  = SCNAction.moveBy(x: 0, y: -0.15, z: 0, duration: 0.1)
        let runBounce = SCNAction.sequence([bounce1, bounce2, bounce1, bounce2,
                                            bounce1, bounce2, bounce1, bounce2])
        runAction(SCNAction.group([forward, runBounce]))
        // Wind-up arm
        let bowlingArm = childNodes.first(where: { $0.position.x > 0 })
        let armSpin = SCNAction.rotateBy(x: 0, y: 0, z: -CGFloat.pi * 2.2, duration: 1.1)
        bowlingArm?.runAction(armSpin) {
            completion()
        }
    }

    func resetPosition(to pos: SCNVector3) {
        removeAllActions()
        position    = pos
        eulerAngles = SCNVector3(0, Float.pi, 0)
    }
}

// MARK: - FielderNode

final class FielderNode: SCNNode {

    override init() {
        super.init()
        setup()
    }
    required init?(coder: NSCoder) { super.init(coder: coder); setup() }

    private func setup() {
        let red  = UIColor(red: 0.75, green: 0.08, blue: 0.08, alpha: 1)
        let skin = UIColor(red: 0.88, green: 0.72, blue: 0.58, alpha: 1)

        addLimb(pos: SCNVector3(-0.1, 0.3, 0), color: UIColor.white, r: 0.09, h: 0.6)
        addLimb(pos: SCNVector3( 0.1, 0.3, 0), color: UIColor.white, r: 0.09, h: 0.6)

        let torso = SCNCapsule(capRadius: 0.21, height: 0.70)
        torso.firstMaterial?.diffuse.contents = red
        let torsoNode = SCNNode(geometry: torso)
        torsoNode.position = SCNVector3(0, 0.88, 0)
        addChildNode(torsoNode)

        addLimb(pos: SCNVector3(-0.3, 0.95, 0), color: red,  r: 0.075, h: 0.44, rotZ:  Float.pi * 0.15)
        addLimb(pos: SCNVector3( 0.3, 0.95, 0), color: red,  r: 0.075, h: 0.44, rotZ: -Float.pi * 0.15)
        addSphere(pos: SCNVector3(0, 1.5, 0), r: 0.19, color: skin)
    }

    func chase(to targetPos: SCNVector3, duration: TimeInterval) {
        let lookDir = SCNVector3(targetPos.x - position.x, 0, targetPos.z - position.z)
        let angle   = atan2(lookDir.x, lookDir.z)
        let turn    = SCNAction.rotateTo(x: 0, y: CGFloat(angle), z: 0, duration: 0.2)
        let move    = SCNAction.move(to: SCNVector3(targetPos.x, 0, targetPos.z), duration: duration)
        runAction(SCNAction.sequence([turn, move]))
    }
}

// MARK: - SCNNode geometry helpers (private extensions used by player nodes above)

extension SCNNode {

    func addLimb(pos: SCNVector3, color: UIColor, r: CGFloat, h: CGFloat, rotZ: Float = 0) {
        let cyl = SCNCylinder(radius: r, height: h)
        cyl.firstMaterial?.diffuse.contents = color
        cyl.firstMaterial?.roughness.contents = 0.9
        let node = SCNNode(geometry: cyl)
        node.position    = pos
        node.eulerAngles = SCNVector3(0, 0, rotZ)
        addChildNode(node)
    }

    func addSphere(pos: SCNVector3, r: CGFloat, color: UIColor) {
        let s = SCNSphere(radius: r)
        s.firstMaterial?.diffuse.contents = color
        s.firstMaterial?.roughness.contents = 0.9
        let node = SCNNode(geometry: s)
        node.position = pos
        addChildNode(node)
    }

    func addBox(pos: SCNVector3, size: (CGFloat, CGFloat, CGFloat), color: UIColor) {
        let b = SCNBox(width: size.0, height: size.1, length: size.2, chamferRadius: 0.02)
        b.firstMaterial?.diffuse.contents = color
        b.firstMaterial?.roughness.contents = 0.9
        let node = SCNNode(geometry: b)
        node.position = pos
        addChildNode(node)
    }
}
