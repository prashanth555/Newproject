import SwiftUI
import Combine

@MainActor
final class ChatViewModel: ObservableObject {

    @Published var messages: [Message] = []
    @Published var isStreaming: Bool = false
    @Published var errorMessage: String? = nil
    @Published var inputText: String = ""

    @AppStorage("anthropic_api_key") var apiKey: String = ""

    private let welcomeMessages = [
        "Ask me anything about cricket! From Bradman's average to Bumrah's action, I've got you covered.",
        "Who's the GOAT? Best IPL knock? Explain swing bowling? Fire away!",
        "Your cricket AI is ready. Let's talk cricket — any format, any era, any question."
    ]

    init() {
        showWelcome()
    }

    private func showWelcome() {
        let welcome = welcomeMessages.randomElement() ?? welcomeMessages[0]
        messages = [Message(role: .assistant, content: welcome)]
    }

    func send() {
        let text = inputText.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty, !isStreaming else { return }

        inputText = ""
        errorMessage = nil

        let userMsg = Message(role: .user, content: text)
        messages.append(userMsg)

        // Append an empty assistant message to stream into
        let assistantMsg = Message(role: .assistant, content: "")
        messages.append(assistantMsg)
        let assistantIndex = messages.count - 1

        isStreaming = true

        // Build conversation history excluding the empty assistant message just added
        let historyToSend = Array(messages.dropLast())

        AnthropicService.shared.sendStreaming(
            messages: historyToSend,
            apiKey: apiKey,
            onToken: { [weak self] token in
                guard let self else { return }
                self.messages[assistantIndex].content += token
            },
            onComplete: { [weak self] in
                self?.isStreaming = false
            },
            onError: { [weak self] error in
                guard let self else { return }
                self.isStreaming = false
                // Replace empty assistant message with error
                self.messages[assistantIndex].content = "Sorry, something went wrong: \(error)"
                self.errorMessage = error
            }
        )
    }

    func clearConversation() {
        messages = []
        showWelcome()
        errorMessage = nil
    }

    var canSend: Bool {
        !inputText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty && !isStreaming
    }
}
