import SwiftUI

struct SettingsView: View {
    @AppStorage("anthropic_api_key") private var apiKey: String = ""
    @State private var showKey: Bool = false
    @State private var tempKey: String = ""
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationView {
            Form {
                Section {
                    VStack(alignment: .leading, spacing: 8) {
                        Label("Anthropic API Key", systemImage: "key.fill")
                            .font(.headline)

                        HStack {
                            Group {
                                if showKey {
                                    TextField("sk-ant-...", text: $tempKey)
                                        .autocapitalization(.none)
                                        .autocorrectionDisabled()
                                        .font(.system(.body, design: .monospaced))
                                } else {
                                    SecureField("sk-ant-...", text: $tempKey)
                                        .font(.system(.body, design: .monospaced))
                                }
                            }

                            Button {
                                showKey.toggle()
                            } label: {
                                Image(systemName: showKey ? "eye.slash" : "eye")
                                    .foregroundColor(.secondary)
                            }
                        }
                        .padding(10)
                        .background(Color(.systemGray6))
                        .cornerRadius(10)

                        Button("Save API Key") {
                            apiKey = tempKey.trimmingCharacters(in: .whitespacesAndNewlines)
                            dismiss()
                        }
                        .buttonStyle(.borderedProminent)
                        .tint(Color("BrandGreen"))
                        .disabled(tempKey.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                    }
                    .padding(.vertical, 8)
                } header: {
                    Text("API Configuration")
                } footer: {
                    Text("Get your API key at console.anthropic.com. The key is stored securely on your device and never shared.")
                        .font(.caption)
                }

                Section("How to get an API key") {
                    VStack(alignment: .leading, spacing: 10) {
                        step(number: "1", text: "Visit console.anthropic.com")
                        step(number: "2", text: "Sign up or log in")
                        step(number: "3", text: "Go to API Keys → Create key")
                        step(number: "4", text: "Paste the key above")
                    }
                    .padding(.vertical, 6)
                }

                Section("About") {
                    HStack {
                        Text("Model")
                        Spacer()
                        Text("Claude Opus 4.5")
                            .foregroundColor(.secondary)
                    }
                    HStack {
                        Text("Focus")
                        Spacer()
                        Text("Cricket Expert")
                            .foregroundColor(.secondary)
                    }
                    HStack {
                        Text("Version")
                        Spacer()
                        Text("1.0.0")
                            .foregroundColor(.secondary)
                    }
                }
            }
            .navigationTitle("Settings")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Done") { dismiss() }
                }
            }
            .onAppear {
                tempKey = apiKey
            }
        }
    }

    private func step(number: String, text: String) -> some View {
        HStack(alignment: .top, spacing: 12) {
            ZStack {
                Circle()
                    .fill(Color("BrandGreen"))
                    .frame(width: 24, height: 24)
                Text(number)
                    .font(.caption.bold())
                    .foregroundColor(.white)
            }
            Text(text)
                .font(.subheadline)
        }
    }
}
