import SwiftUI

struct ChatView: View {
    @StateObject private var viewModel = ChatViewModel()
    @State private var showSettings = false
    @State private var showSuggestions = true
    @FocusState private var inputFocused: Bool

    var body: some View {
        NavigationView {
            VStack(spacing: 0) {
                // API key banner
                if viewModel.apiKey.isEmpty {
                    apiKeyBanner
                }

                // Messages list
                ScrollViewReader { proxy in
                    ScrollView {
                        LazyVStack(spacing: 12) {
                            ForEach(viewModel.messages) { message in
                                MessageBubble(
                                    message: message,
                                    isStreaming: viewModel.isStreaming && message == viewModel.messages.last
                                )
                                .id(message.id)
                            }
                        }
                        .padding(.vertical, 16)
                        .animation(.spring(response: 0.35, dampingFraction: 0.85), value: viewModel.messages.count)
                    }
                    .onChange(of: viewModel.messages.last?.content) { _ in
                        if let last = viewModel.messages.last {
                            withAnimation {
                                proxy.scrollTo(last.id, anchor: .bottom)
                            }
                        }
                    }
                }

                Divider()

                // Suggested questions (only when conversation is fresh)
                if showSuggestions && viewModel.messages.count <= 1 {
                    SuggestedQuestionsView { question in
                        viewModel.inputText = question
                        showSuggestions = false
                        viewModel.send()
                        inputFocused = false
                    }
                }

                // Input bar
                inputBar
            }
            .navigationTitle("CricketGPT")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button {
                        viewModel.clearConversation()
                        showSuggestions = true
                    } label: {
                        Image(systemName: "arrow.counterclockwise")
                    }
                }

                ToolbarItem(placement: .principal) {
                    HStack(spacing: 6) {
                        Text("🏏")
                        Text("CricketGPT")
                            .font(.headline)
                        if viewModel.isStreaming {
                            Circle()
                                .fill(Color("BrandGreen"))
                                .frame(width: 8, height: 8)
                                .transition(.scale.combined(with: .opacity))
                        }
                    }
                    .animation(.easeInOut(duration: 0.2), value: viewModel.isStreaming)
                }

                ToolbarItem(placement: .navigationBarTrailing) {
                    Button {
                        showSettings = true
                    } label: {
                        Image(systemName: "gearshape")
                    }
                }
            }
            .sheet(isPresented: $showSettings) {
                SettingsView()
            }
            .background(Color(.systemBackground))
        }
        .navigationViewStyle(.stack)
    }

    // MARK: - Input Bar

    private var inputBar: some View {
        HStack(alignment: .bottom, spacing: 10) {
            TextField("Ask about cricket...", text: $viewModel.inputText, axis: .vertical)
                .padding(.horizontal, 14)
                .padding(.vertical, 10)
                .background(Color(.systemGray6))
                .cornerRadius(22)
                .lineLimit(1...5)
                .focused($inputFocused)
                .onSubmit {
                    if viewModel.canSend {
                        showSuggestions = false
                        viewModel.send()
                    }
                }
                .submitLabel(.send)

            Button {
                showSuggestions = false
                inputFocused = false
                viewModel.send()
            } label: {
                Image(systemName: viewModel.isStreaming ? "stop.circle.fill" : "arrow.up.circle.fill")
                    .resizable()
                    .frame(width: 36, height: 36)
                    .foregroundColor(viewModel.canSend ? Color("BrandGreen") : Color.secondary)
                    .animation(.easeInOut(duration: 0.15), value: viewModel.isStreaming)
            }
            .disabled(!viewModel.canSend)
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 10)
        .background(Color(.systemBackground))
    }

    // MARK: - API Key Banner

    private var apiKeyBanner: some View {
        Button {
            showSettings = true
        } label: {
            HStack(spacing: 8) {
                Image(systemName: "exclamationmark.triangle.fill")
                    .foregroundColor(.orange)
                Text("Tap to add your Anthropic API key to start chatting")
                    .font(.subheadline)
                    .foregroundColor(.primary)
                Spacer()
                Image(systemName: "chevron.right")
                    .foregroundColor(.secondary)
                    .font(.caption)
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 10)
            .background(Color.orange.opacity(0.12))
        }
    }
}
