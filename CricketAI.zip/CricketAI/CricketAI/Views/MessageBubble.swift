import SwiftUI

struct MessageBubble: View {
    let message: Message
    let isStreaming: Bool

    private var isUser: Bool { message.isUser }

    var body: some View {
        HStack(alignment: .bottom, spacing: 8) {
            if isUser { Spacer(minLength: 60) }

            if !isUser {
                botAvatar
            }

            VStack(alignment: isUser ? .trailing : .leading, spacing: 4) {
                bubbleBody
                timestamp
            }

            if !isUser { Spacer(minLength: 60) }
        }
        .padding(.horizontal, 12)
        .transition(.asymmetric(
            insertion: .push(from: isUser ? .trailing : .leading).combined(with: .opacity),
            removal: .opacity
        ))
    }

    private var botAvatar: some View {
        ZStack {
            Circle()
                .fill(LinearGradient(
                    colors: [Color("BrandGreen"), Color("BrandDark")],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                ))
            Text("🏏")
                .font(.system(size: 16))
        }
        .frame(width: 34, height: 34)
    }

    private var bubbleBody: some View {
        Group {
            if message.content.isEmpty && isStreaming {
                TypingIndicator()
                    .padding(.horizontal, 16)
                    .padding(.vertical, 12)
            } else {
                Text(message.content)
                    .font(.system(size: 16))
                    .foregroundColor(isUser ? .white : .primary)
                    .padding(.horizontal, 14)
                    .padding(.vertical, 10)
                    .multilineTextAlignment(isUser ? .trailing : .leading)
            }
        }
        .background(bubbleBackground)
        .clipShape(BubbleShape(isUser: isUser))
        .shadow(color: .black.opacity(0.06), radius: 4, x: 0, y: 2)
    }

    @ViewBuilder
    private var bubbleBackground: some View {
        if isUser {
            LinearGradient(
                colors: [Color("BrandGreen"), Color("BrandDark")],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
        } else {
            Color(.systemGray6)
        }
    }

    private var timestamp: some View {
        Text(message.timestamp, style: .time)
            .font(.caption2)
            .foregroundColor(.secondary)
            .padding(.horizontal, 4)
    }
}

// MARK: - Custom Bubble Shape

struct BubbleShape: Shape {
    let isUser: Bool
    let radius: CGFloat = 18
    let tailRadius: CGFloat = 4

    func path(in rect: CGRect) -> Path {
        var path = Path()
        let r = radius
        let tr = tailRadius

        if isUser {
            // Rounded on left, small tail on bottom-right
            path.move(to: CGPoint(x: rect.minX + r, y: rect.minY))
            path.addLine(to: CGPoint(x: rect.maxX - r, y: rect.minY))
            path.addArc(center: CGPoint(x: rect.maxX - r, y: rect.minY + r),
                        radius: r, startAngle: .degrees(-90), endAngle: .degrees(0), clockwise: false)
            path.addLine(to: CGPoint(x: rect.maxX, y: rect.maxY - tr))
            path.addArc(center: CGPoint(x: rect.maxX - tr, y: rect.maxY - tr),
                        radius: tr, startAngle: .degrees(0), endAngle: .degrees(90), clockwise: false)
            path.addLine(to: CGPoint(x: rect.minX + r, y: rect.maxY))
            path.addArc(center: CGPoint(x: rect.minX + r, y: rect.maxY - r),
                        radius: r, startAngle: .degrees(90), endAngle: .degrees(180), clockwise: false)
            path.addLine(to: CGPoint(x: rect.minX, y: rect.minY + r))
            path.addArc(center: CGPoint(x: rect.minX + r, y: rect.minY + r),
                        radius: r, startAngle: .degrees(180), endAngle: .degrees(270), clockwise: false)
        } else {
            // Small tail on bottom-left, rounded on right
            path.move(to: CGPoint(x: rect.minX + r, y: rect.minY))
            path.addLine(to: CGPoint(x: rect.maxX - r, y: rect.minY))
            path.addArc(center: CGPoint(x: rect.maxX - r, y: rect.minY + r),
                        radius: r, startAngle: .degrees(-90), endAngle: .degrees(0), clockwise: false)
            path.addLine(to: CGPoint(x: rect.maxX, y: rect.maxY - r))
            path.addArc(center: CGPoint(x: rect.maxX - r, y: rect.maxY - r),
                        radius: r, startAngle: .degrees(0), endAngle: .degrees(90), clockwise: false)
            path.addLine(to: CGPoint(x: rect.minX + tr, y: rect.maxY))
            path.addArc(center: CGPoint(x: rect.minX + tr, y: rect.maxY - tr),
                        radius: tr, startAngle: .degrees(90), endAngle: .degrees(180), clockwise: false)
            path.addLine(to: CGPoint(x: rect.minX, y: rect.minY + r))
            path.addArc(center: CGPoint(x: rect.minX + r, y: rect.minY + r),
                        radius: r, startAngle: .degrees(180), endAngle: .degrees(270), clockwise: false)
        }
        path.closeSubpath()
        return path
    }
}
