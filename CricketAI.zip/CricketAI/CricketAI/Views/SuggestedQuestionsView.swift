import SwiftUI

struct SuggestedQuestionsView: View {
    let onSelect: (String) -> Void

    private let questions = [
        "Who has the highest Test batting average ever?",
        "Explain the Duckworth-Lewis method",
        "Who are the best T20 batters right now?",
        "What makes Jasprit Bumrah's action unique?",
        "Greatest ODI knock of all time?",
        "How does reverse swing work?"
    ]

    var body: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 10) {
                ForEach(questions, id: \.self) { q in
                    Button {
                        onSelect(q)
                    } label: {
                        Text(q)
                            .font(.subheadline)
                            .foregroundColor(.primary)
                            .padding(.horizontal, 14)
                            .padding(.vertical, 8)
                            .background(Color(.systemGray6))
                            .cornerRadius(20)
                            .overlay(
                                RoundedRectangle(cornerRadius: 20)
                                    .stroke(Color("BrandGreen").opacity(0.4), lineWidth: 1)
                            )
                    }
                }
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 6)
        }
    }
}
