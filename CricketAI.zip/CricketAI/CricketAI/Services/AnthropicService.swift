import Foundation

// MARK: - Streaming Delegate

final class StreamingDelegate: NSObject, URLSessionDataDelegate {
    var onToken: ((String) -> Void)?
    var onComplete: (() -> Void)?
    var onError: ((Error) -> Void)?

    private var buffer = ""

    func urlSession(_ session: URLSession,
                    dataTask: URLSessionDataTask,
                    didReceive data: Data) {
        guard let chunk = String(data: data, encoding: .utf8) else { return }
        buffer += chunk
        processBuffer()
    }

    func urlSession(_ session: URLSession,
                    task: URLSessionTask,
                    didCompleteWithError error: Error?) {
        if let error {
            onError?(error)
        } else {
            onComplete?()
        }
    }

    private func processBuffer() {
        // SSE events are separated by "\n\n"
        while let range = buffer.range(of: "\n\n") {
            let eventBlock = String(buffer[..<range.lowerBound])
            buffer = String(buffer[range.upperBound...])
            parseEvent(eventBlock)
        }
    }

    private func parseEvent(_ block: String) {
        for line in block.split(separator: "\n", omittingEmptySubsequences: false) {
            let lineStr = String(line)
            guard lineStr.hasPrefix("data: ") else { continue }
            let payload = String(lineStr.dropFirst(6))
            if payload == "[DONE]" { return }
            guard let jsonData = payload.data(using: .utf8),
                  let event = try? JSONDecoder().decode(StreamEvent.self, from: jsonData)
            else { continue }

            if event.type == "content_block_delta",
               event.delta?.type == "text_delta",
               let text = event.delta?.text {
                onToken?(text)
            }
        }
    }
}

// MARK: - Anthropic Service

final class AnthropicService {

    static let shared = AnthropicService()
    private init() {}

    private let endpoint = URL(string: "https://api.anthropic.com/v1/messages")!
    private let apiVersion = "2023-06-01"
    private let model = "claude-opus-4-5"

    private let systemPrompt = """
    You are CricketGPT — a world-class cricket analyst, statistician, and enthusiast. \
    You have deep expertise across all cricket formats: Test, ODI, T20I, IPL, BBL, PSL, \
    The Hundred, and all major domestic leagues. Your knowledge covers:

    • Laws of Cricket and playing conditions
    • Player statistics, records, and career trajectories (historical and current)
    • Team histories, strengths, weaknesses, and tactical setups
    • Match strategy — field placements, bowling changes, batting orders, powerplay tactics
    • Iconic matches and unforgettable moments in cricket history
    • Pitch and weather conditions and how they affect play
    • Fantasy cricket tips and player form analysis
    • Cricket terminology and jargon explained clearly

    Engage naturally in a conversational, interactive session. Remember everything said \
    earlier in this conversation. If someone asks a follow-up question like "and what about \
    his ODI record?" you understand the context. Be enthusiastic, insightful, and thorough. \
    Use cricket metaphors and examples to make answers vivid. When statistics are cited, \
    present them clearly. Always be helpful and engaging — think of yourself as a knowledgeable \
    friend who happens to be a cricket expert.
    """

    // MARK: - Streaming send

    func sendStreaming(
        messages: [Message],
        apiKey: String,
        onToken: @escaping (String) -> Void,
        onComplete: @escaping () -> Void,
        onError: @escaping (String) -> Void
    ) {
        guard !apiKey.isEmpty else {
            onError("API key is missing. Please add your Anthropic API key in Settings.")
            return
        }

        let apiMessages = messages.map { msg in
            AnthropicMessage(role: msg.role.rawValue, content: msg.content)
        }

        let requestBody = AnthropicRequest(
            model: model,
            maxTokens: 2048,
            system: systemPrompt,
            messages: apiMessages,
            stream: true
        )

        guard let bodyData = try? JSONEncoder().encode(requestBody) else {
            onError("Failed to encode request.")
            return
        }

        var request = URLRequest(url: endpoint)
        request.httpMethod = "POST"
        request.setValue(apiKey, forHTTPHeaderField: "x-api-key")
        request.setValue(apiVersion, forHTTPHeaderField: "anthropic-version")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = bodyData

        let delegate = StreamingDelegate()
        delegate.onToken = { token in
            DispatchQueue.main.async { onToken(token) }
        }
        delegate.onComplete = {
            DispatchQueue.main.async { onComplete() }
        }
        delegate.onError = { error in
            DispatchQueue.main.async { onError(error.localizedDescription) }
        }

        let session = URLSession(configuration: .default, delegate: delegate, delegateQueue: nil)
        session.dataTask(with: request).resume()
    }
}
