import SwiftUI

@main
struct CricketAIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
                .preferredColorScheme(.none)
        }
    }
}
