import Foundation

// MARK: - Chat Message

struct Message: Identifiable, Equatable {
    let id: UUID
    let role: Role
    var content: String
    let timestamp: Date

    init(role: Role, content: String) {
        self.id = UUID()
        self.role = role
        self.content = content
        self.timestamp = Date()
    }

    enum Role: String, Codable {
        case user
        case assistant
    }

    var isUser: Bool { role == .user }
}

// MARK: - Anthropic API Models

struct AnthropicRequest: Encodable {
    let model: String
    let maxTokens: Int
    let system: String
    let messages: [AnthropicMessage]
    let stream: Bool

    enum CodingKeys: String, CodingKey {
        case model
        case maxTokens = "max_tokens"
        case system
        case messages
        case stream
    }
}

struct AnthropicMessage: Codable {
    let role: String
    let content: String
}

// MARK: - Streaming Event Models

struct StreamEvent: Decodable {
    let type: String
    let delta: Delta?
    let index: Int?

    struct Delta: Decodable {
        let type: String?
        let text: String?
    }
}

// MARK: - Non-streaming Response

struct AnthropicResponse: Decodable {
    let content: [ContentBlock]

    struct ContentBlock: Decodable {
        let type: String
        let text: String
    }
}

// MARK: - Error Response

struct AnthropicError: Decodable {
    let error: ErrorDetail

    struct ErrorDetail: Decodable {
        let type: String
        let message: String
    }
}
